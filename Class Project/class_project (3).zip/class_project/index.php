<?php

include "inc/header.php";


if(isset($_GET['enroll'])){
    if(isset($_SESSION['User'])){
        $course = $_GET['enroll'];
        $user = $usrData['id'];
        $userc->enrollCourse($course,$user);
    }else{
        header("location: login.php");
    }
}
?>
<section id="body">
    <div class="container">
        <div class="row hed mb-3">
            <div class="col-md-6"><h3 class='my-3'>Our Courses</h3></div>
            <div class="col-md-6">
            <form class="form-inline my-3 text-right d-block">
                <input class="form-control mr-sm-2" type="search" name="src" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success my-sm-0" type="submit">Search</button>
            </form>
            </div>
        </div>
        <div class="row">
            <?php 
                if(isset($_GET['src'])){
                    $src = $_GET['src'];
                    $srcCourse = $config->query("SELECT * FROM `course` WHERE CONCAT_WS(`id` , `name` , `instructor`) LIKE '%$src%'");
                    $rows = mysqli_num_rows($srcCourse);
                    if($rows == 0){
                    ?>
                    <div class="col-12">
                        <h2 class="text-warning text-center">No data available</h2>
                    </div>
                    <?php
                    }else{
                        while($srccourse = mysqli_fetch_assoc($srcCourse)){
                            if (isset($_SESSION['User'])){
                                $username = $_SESSION['User'];
                                $selUser = $config->query("SELECT * FROM `users` WHERE `username` = '$username'");
                                $usrData = mysqli_fetch_assoc($selUser);
                                $id = $usrData['id'];
                                $courseid = $srccourse['id'];
                                $select = $config->query("SELECT * FROM `enrolled` where `courseid`like'$courseid'and`userid`='$id'");
                                $num_rows = mysqli_num_rows($select);
                            }
                            ?>
                            <div class="col-md-6 col-lg-3 my-3">
                                <div class="course_con">
                                    <div class="row m-0">
                                        <div class="col-4 pr-0">
                                            <p class="font-weight-bold mb-1 mt-1">Id</p>
                                            <p class="font-weight-bold mb-1 mt-1">Name</p>
                                            <p class="font-weight-bold mb-1 mt-1">Semester</p>
                                            <p class="font-weight-bold mb-1 mt-1">Instructor</p>
                                            <p class="font-weight-bold mb-1 mt-1">Class room</p>
                                            <p class="font-weight-bold mb-1 mt-1">Time</p>
                                        </div>
                                        <div class="col-8 pr-0">
                                            <p class="mb-1 mt-1">: <?= $srccourse['id'] ?></p>
                                            <p class="mb-1 mt-1">: <?= $srccourse['name'] ?></p>
                                            <p class="mb-1 mt-1">: <?= $srccourse['semester'] ?></p>
                                            <p class="mb-1 mt-1">: <?= $srccourse['instructor'] ?></p>
                                            <p class="mb-1 mt-1">: <?= $srccourse['classroom'] ?></p>
                                            <p class="mb-1 mt-1">: <?= $srccourse['time'] ?></p>
                                        </div>
                                        <?php
                                        if (isset($_SESSION['User'])){
                                            ?>
                                            <a <?= $num_rows==1?'disabled':'' ?> class="btn <?= $num_rows==1?'disabled':'' ?> btn-block btn-outline-success" href=" <?= $num_rows==1?'#':'?enroll='.$srccourse['id'] ?>"><?= $num_rows==1?'Enrolled':'Enroll' ?></a>
                                            <?php
                                        }else{
                                            ?>
                                            <a class="btn btn-block btn-outline-success" href="?enroll=<?= $srccourse['id'] ?>">Enroll</a>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    }
                }else{
                while($course = mysqli_fetch_assoc($selCourse)){
                    if (isset($_SESSION['User'])){
                        $username = $_SESSION['User'];
                        $selUser = $config->query("SELECT * FROM `users` WHERE `username` = '$username'");
                        $usrData = mysqli_fetch_assoc($selUser);
                        $id = $usrData['id'];
                        $courseid = $course['id'];
                        $select = $config->query("SELECT * FROM `enrolled` where `courseid`like'$courseid'and`userid`='$id'");
                        $num_rows = mysqli_num_rows($select);
                    }

                ?>
                <div class="col-md-6 col-lg-3 my-3">
                    <div class="course_con">
                        <div class="row m-0">
                            <div class="col-4 pr-0">
                                <p class="font-weight-bold mb-1 mt-1">Id</p>
                                <p class="font-weight-bold mb-1 mt-1">Name</p>
                                <p class="font-weight-bold mb-1 mt-1">Semester </p>
                                <p class="font-weight-bold mb-1 mt-1">Instructor</p>
                                <p class="font-weight-bold mb-1 mt-1">Class room</p>
                                <p class="font-weight-bold mb-1 mt-1">Time</p>
                            </div>
                            <div class="col-8 pr-0">
                                <p class="mb-1 mt-1">: <?= $course['id'] ?></p>
                                <p class="mb-1 mt-1">: <?= $course['name'] ?></p>
                                <p class="mb-1 mt-1">: <?= $course['semester'] ?></p>
                                <p class="mb-1 mt-1">: <?= $course['instructor'] ?></p>
                                <p class="mb-1 mt-1">: <?= $course['classroom'] ?></p>
                                <p class="mb-1 mt-1">: <?= $course['time'] ?></p>
                            </div>
                            <?php
                            if (isset($_SESSION['User'])){
                            ?>
                                <a <?= $num_rows==1?'disabled':'' ?> class="btn <?= $num_rows==1?'disabled':'' ?> btn-block btn-outline-success" href=" <?= $num_rows==1?'#':'?enroll='.$course['id'] ?>"><?= $num_rows==1?'Enrolled':'Enroll' ?></a>
                                <?php
                            }else{
                                ?>
                                <a class="btn btn-block btn-outline-success" href="?enroll=<?= $course['id'] ?>">Enroll</a>
                                <?php
                            }
                                ?>
                        </div>
                    </div>
                </div>
            <?php } }  ?>
        </div>
    </div>
</section>
</body>
</html>