<?php
    include "inc/header.php";
?>
<section id="body">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <div class="profile_con">
                    <a href="editprofiel.php">Edit Profile</a>
                </div>
                <div class="row">
                    <form action="">
                        <input type="text" class="form-controll" value="<?= $usrData['username'] ?>">
                        <input type="text" class="form-controll" value="<?= $usrData['birthday'] ?>">
                        <button type="submit" name="saveData"></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
</body>
</html>