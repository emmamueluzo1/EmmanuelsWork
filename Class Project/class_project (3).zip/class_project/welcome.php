<?php
session_start();
if (!isset($_SESSION['User'])){
    header("location:login.php");
    exit();
}

include "php/auto.php" ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Your email address</title>
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body>
    <div class="col-md-6 mx-auto">
        <div class="welcome alert">
        <h3 class="text-success text-center">Registration Successful</h3>
        <?php if(isset($_GET['verify'])){
                $config = new Config;
                $auth = $_GET['verify'];
                $checkauth = $config->checexist("SELECT * FROM `users` WHERE `auth`='$auth'");
                if($checkauth == true){
                    $upuser = $config->query("UPDATE `users` SET `verify`='1' WHERE `auth`='$auth'");
                    if($upuser == true){
                        echo "<script>window.location.href='login.php'</script>";
                    }else{
                        ?>
                            <div class="alert alert-warning">Something's wrong</div>
                        <?php
                    }
                }else{
                    ?>
                        <div class="alert alert-warning">Invalid link</div>
                    <?php
                }
            }else{
                ?>
                <span>Hi <?= isset($_GET['nm'] )? $_GET['nm']:'' ?></span>
                <p>We have sent an email to <b><?= isset($_GET['registerd'])? $_GET["registerd"]:'' ?></b> check your inbox and verify your email address</p>
            <?php
            }
            ?>
        </div>
    </div>
</body>
</html>