<?php
    include "php/auto.php";
    if (isset($_SESSION['User'])){
        header("location:index.php");
        exit();
    }elseif (isset($_POST['registraion'])){
        $userReg = $user->registration($_POST);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>User Registration</title>
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
</head>

<body>
	<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
        <div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
			<form class="login100-form validate-form" action="" method="post">
                <span class="login100-form-title p-b-15">
					User Registration
				</span>
                <p class='p-b-15'>If you already have an account click here to <b><a href="login.php">login</a></b></p>
                <?php if(isset($user->err)){?><div class="alert alert-danger text-center"><?= $user->err ?></div> <?php } ?>
				<div class="wrap-input100 validate-input m-b-20" data-validate="Enter Username">
					<input class="input100" type="text" name="name" placeholder="Username">
					<span class="focus-input100"></span>
				</div>
                
                <div class="wrap-input100 validate-input m-b-25" data-validate = "Enter Email">
                    <input class="input100" type="email" name="email" placeholder="Email" required>
                    <span class="focus-input100"></span>
				</div>
                <div class="wrap-input100 validate-input m-b-25" data-validate = "Select Gender">
                    <select class="input100 border-0 gensel" name="gender" id="gender">
                        <option value="">--Gender--</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="coustom">Custom</option>
                    </select>
                    <span class="focus-input100"></span>
				</div>
                <div class="wrap-input100 validate-input m-b-25" data-validate = "Enter Password">
                    <input class="input100" type="password" name="pass" placeholder="Password" required>
                    <span class="focus-input100"></span>
				</div>
                <div class="wrap-input100 validate-input m-b-25" data-validate = "Enter Confirm password">
                    <input class="input100" type="Password" name="con_pass" placeholder="Confirm Password" required>
                    <span class="focus-input100"></span>
				</div>
				<div class="container-login100-form-btn">
					<button class="login100-form-btn" name="registraion">
						Register
					</button>
				</div>
            </form>
        </div>
    </div>
    <div id="dropDownSelect1"></div>
    <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
    <script src="vendor/animsition/js/animsition.min.js"></script>
    <script src="vendor/bootstrap/js/popper.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/daterangepicker/moment.min.js"></script>
    <script src="vendor/daterangepicker/daterangepicker.js"></script>
    <script src="vendor/countdowntime/countdowntime.js"></script>
    <script src="js/main.js"></script>
</body>

</html>