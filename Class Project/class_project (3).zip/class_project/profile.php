<?php
  
  $title = "Profile";
  include "inc/header.php";
if(isset($_GET['withdraw'])){
    $userc->withdrawCourse($_GET);
}
if(isset($_SESSION['User'])){
   
?>
<section id="body">
    <div class="container">
                    
        <div class="row">
            <div class="col-sm-8 col-md-6 col-lg-5 mx-auto my-5">
                <div class="profile_con">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="text-center"><?= $usrData['username'] ?></h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6"><p class="my-1"><b>Email</b></p></div>
                        <div class="col-6"><p class="my-1">: <?= $usrData['email'] ?></p></div>
                    </div>
                    <div class="row">
                        <div class="col-6"><p class="my-1"><b>Birthday</b></p></div>
                        <div class="col-6"><p class="my-1">: <?= $usrData['birthday'] ?></p></div>
                    </div>
                    <div class="row">
                        <div class="col-6"><p class="my-1"><b>Gender</b></p></div>
                        <div class="col-6"><p class="my-1">: <?= $usrData['gender'] ?></p></div>
                    </div>
                </div>
                <div class="text-right">
                    <a class="btn btn-primary d-inline-block" href="editprofile.php">Edit Profile</a>

                </div>
            </div>
        </div>
        <div class="row">
        <?php
            $id = $usrData['id'];
            $selEnCrsid = $config->query("SELECT * FROM `enrolled` WHERE `userid`='$id'");
            while($enrolledCrsID = mysqli_fetch_assoc($selEnCrsid)){ 
                $crsid = $enrolledCrsID['courseid'];
                $selEnCrs = $config->query("SELECT * FROM `course` WHERE `id`='$crsid'");
                $crs = mysqli_fetch_assoc($selEnCrs);
                ?>
            <div class="col-md-6 col-lg-3 my-3">
                <div class="course_con">
                    <div class="row m-0">
                        <div class="col-4 pr-0">
                            <p class="font-weight-bold mb-1 mt-1">Id</p>
                            <p class="font-weight-bold mb-1 mt-1">Name</p>
                            <p class="font-weight-bold mb-1 mt-1">Semester</p>
                            <p class="font-weight-bold mb-1 mt-1">Instructor</p>
                            <p class="font-weight-bold mb-1 mt-1">Class room</p>
                            <p class="font-weight-bold mb-1 mt-1">Time</p>
                        </div>
                        <div class="col-8 pr-0">
                            <p class="mb-1 mt-1">: <?= $crs['id'] ?></p>
                            <p class="mb-1 mt-1">: <?= $crs['name'] ?></p>
                            <p class="mb-1 mt-1">: <?= $crs['semester'] ?></p>
                            <p class="mb-1 mt-1">: <?= $crs['instructor'] ?></p>
                            <p class="mb-1 mt-1">: <?= $crs['classroom'] ?></p>
                            <p class="mb-1 mt-1">: <?= $crs['time'] ?></p>
                        </div>
                        <a class="btn btn-block btn-success" href="?withdraw=<?= $enrolledCrsID['id'] ?>">Withdraw</a>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</section>
</body>
</html>
    <?php }else{ 
        header("location: login.php");
    } ?>