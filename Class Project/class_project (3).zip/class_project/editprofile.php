<?php
    $title = "Edit Profile";
    include "inc/header.php";
if(isset( $_SESSION['User'])){
    if(isset($_POST['savePrf'])){
        $user->updateUserData($_POST);
    }elseif(isset($_POST['savePass'])){
        $user->updateUserPass($_POST);
    }
?>
<section id="body">
    <div class="container">
    <div class="row">
            <div class="col-md-8 col-lg-6 mx-auto">
            <?php if(isset($user->err)){?>
            <div class="alert alert-warning text-center my-3"><?= $user->err; ?></div> 
            <?php }elseif(isset($user->succ)){ ?>
            <div class="alert alert-success text-center my-3"><?= $user->succ; ?></div> <?php } ?>
            <?php if(isset($_GET['succ'])){ ?>
            <div class="alert alert-success text-center my-3">Profile updated successfully</div> <?php } ?>
            <h4 class="my-3">Edit profile</h4>
                <form action="" method="POST">
                    <div class="form-group row">
                        <label for="name" class="col-sm-2 col-form-label">Name</label>
                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="name"  value="<?= $usrData['username'] ?>" name="username" placeholder="User Name">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="birthday" class="col-sm-2 col-form-label">Birthday</label>
                        <div class="col-sm-10">
                        <input type="date" class="form-control" id="birthday"  value="<?= $usrData['birthday'] ?>" name="birthday" placeholder="Birthday">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="gender" class="col-sm-2 col-form-label">Gender</label>
                        <div class="col-sm-10">
                        <select class="form-control" name="gender" id="gender">
                            <option value="">--Gender--</option>
                            <option value="male" <?= $usrData['gender']=='male' ?'selected':'' ?> >Male</option>
                            <option value="female" <?= $usrData['gender']=='female' ?'selected':'' ?> >Female</option>
                            <option value="coustom" <?= $usrData['gender']=='coustom' ?'selected':'' ?> >Coustom</option>
                        </select>
                        </div>
                    </div>
                    <div class="text-center">
                        <input type="hidden" name="id" value="<?= $usrData['id'] ?>">
                        <button class="btn btn-primary" type="submit" name="savePrf">Save</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-8 col-md-7 col-lg-5 mx-auto">
            <h4 class="my-3">Change Password</h4>
                <form action="" method="POST">
                    <div class="form-group">
                        <label for="oldpass">Old Password</label>
                        <input type="password" class="form-control" id="oldpass" name="oldpass" placeholder="Enter Old Password">
                        <input type="hidden" name="dbpass" value="<?= $usrData['password'] ?>">
                        <input type="hidden" name="email" value="<?= $usrData['email'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="newpass">New Password</label>
                        <input type="password" class="form-control" id="newpass" name="newpass" placeholder="Enter New Password">
                    </div>
                    <div class="form-group">
                        <label for="cnfpass">Confirm Password</label>
                        <input type="password" class="form-control" id="cnfpass" name="cnfpass" placeholder="Enter Confirm Password">
                        <input type="hidden" name="id" value="<?= $usrData['id'] ?>">
                    </div>
                    <div class="text-center">
                        <button class="btn btn-primary" type="submit" name="savePass">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
</body>
</html>
<?php }else{ 
        header("location: login.php");
    } ?>