<?php
include "php/auto.php";
$config = new Config();
$selCourse = $config->query("SELECT * FROM `course` WHERE `availability`='available'");
$userc = new User();
if(isset($_SESSION['User'])){
    $username = $_SESSION['User'];
    $selUser = $config->query("SELECT * FROM `users` WHERE `username`='$username'");
    $usrData = mysqli_fetch_assoc($selUser);
    $id = $usrData['id'];
    
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($title)? $title:'Home' ?></title>
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body>
<header id="header">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">AUM Class Registration</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
            </ul>
            <ul class="ml-auto list-unstyled">
                <li><span><?php if(isset($_SESSION['User'])){ ?><a class="text-white" href="profile.php">Profile</a> | <a class="text-danger" href="logout.php"><i class="fa fa-sign-out"></i> Logout</a><?php }else{ ?><a class="text-white" href="login.php">login</a><?php } ?></span></li>
            </ul>
        </div>
    </nav>
</header>