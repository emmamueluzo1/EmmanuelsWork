<?php
session_start();
include "Config.php";
include "User.php";
include "mail.php";
$config = new Config();
$user = new User();