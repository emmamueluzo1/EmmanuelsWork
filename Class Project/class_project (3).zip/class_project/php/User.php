<?php

    class User
    {
        
        public $err;
        public $succ;
        public function login($data)
        {
            $config = new Config();
            $username = $data['username'];
            $password = $data['password'];
            $enpass = md5(sha1($password));
            $select = $config->query("SELECT * FROM `users` WHERE `username`like'$username'and`password`like'$enpass'");
            $num_rows = mysqli_num_rows($select);
            if ($num_rows == 1){
                $data = mysqli_fetch_assoc($select);
                $usernamedb = $data['username'];
                $verify = $data['verify'];
                return $usernamedb;
//                if($verify == 1){
//                    return $usernamedb;
//
//                }else{
//                    return 2;
//                }
            }else{
                return false;
            }
        }
        public function registration($data)
        {
            $config = new Config();
            $name = $data['name'];
            $email = $data['email'];
            $gender = strtolower($data['gender']);
            $pass = $data['pass'];
            $con_pass = $data['con_pass'];
            if(empty($name) || empty($gender) || empty($email) || empty($pass) || empty($con_pass)){
                return $this->err= "Somthing Want Wrong";
            }else{
                if(strlen($pass) < 8 ){
                    return $this->err= "Password Must be 8 character or more";
                    exit();
                }else{
                    if($pass == $con_pass){
                        $chname = $config->checexist("SELECT * FROM `users` WHERE `username`='$name'");
                        if($chname == true){
                            $this->err = "Username already Exist";
                        }else{
                            $chmail = $config->checexist("SELECT * FROM `users` WHERE `email`='$email'");
                            if($chmail == true){
                                $this->err = "Email already Exist";
                            }else{
                                $enpass = md5(sha1($pass));
                                $auth = md5(sha1($pass.$email));
                                $reg = $config->query("INSERT INTO `users`(`username`, `email`, `gender`, `password`, `auth`) VALUES ('$name','$email','$gender','$enpass','$auth')"); 
                                if($reg == true){
                                    registerVerify($email,$name,$auth);
                                }else{
                                    $this->err = "Somthing wrong";
                                }
                            }
                        }
                    }else{
                        return $this->err= "Password did not match";
                    }
                }
            }
        }

        public function updateUserData($data){
            $config = new Config();
            $name = $data['username'];
            $id = $data['id'];
            $birthday = $data['birthday'];
            $gender = $data['gender'];
            if(empty($name) || empty($gender) || empty($birthday)){
                return $this->err= "Ummm!! Somthing Went Wrong";
            }else{
                $upUsrData = $config->query("UPDATE `users` SET `username`='$name',`birthday`='$birthday',`gender`='$gender' WHERE `id`='$id'");
                if($upUsrData == true){
                    $this->succ = "Profile updated successully";
                    header("location: editprofile.php?succ");
                }else{
                    $this->err = "Something's Wrong!!";
                }
            }
            
        }
        
        public function updateUserPass($data){
            $config = new Config();
            $old = $data['oldpass'];
            $new = $data['newpass'];
            $conf = $data['cnfpass'];
            $dbpass = $data['dbpass'];
            $email = $data['email'];
            $id = $data['id'];
            if(empty($old) || empty($new) || empty($conf)){
                return $this->err= "Ummm!! Somthing Went Wrong";
            }else{
                $enOld = md5(sha1($old));
                if($enOld == $dbpass){
                    if(strlen($new) < 8){
                        $this->err = "New Password must be 8 characters or more";
                    }else{
                        if($new == $conf){
                            $enconf = md5(sha1($conf));
                            $auth = md5(sha1($conf.$email));
                            $upUsrData = $config->query("UPDATE `users` SET `password`='$enconf',`auth`='$auth' WHERE `id`='$id'");
                            if($upUsrData == true){
                                $this->succ = "Password changed successully";
                                header("location: logout.php");
                            }else{
                                $this->err = "Something's Wrong";
                            }
                        }else{
                            $this->err = "Password did not match";
                        }
                    }
                }else{
                    $this->err = "Old Password is incorrect";
                }
            }
            
        }

        public function enrollCourse($course,$user)
        {
            $config = new Config();
            $enroll = $config->query("INSERT INTO `enrolled`(`courseid`, `userid`) VALUES ('$course','$user')");
            if($enroll == true){
                header("location:index.php?enrolled");
            }else{
                header("location:index.php?notenrolled");
            }
        }

        public function withdrawCourse($data)
        {
            $config = new Config();
            $id = $data['withdraw'];
            $enroll = $config->query("DELETE FROM `enrolled` WHERE `id`='$id'");
            if($enroll == true){
                header("location:profile.php");
            }else{
                header("location:profile.php");
            }
        }

    }