<?php


class Config
{
    public $musr = "freelancerazad47@gmail.com";
    public $mpass = "government";
    public $mhost = "smtp.gmail.com";
    public $url = "http://localhost/class_project/welcome.php";
    
    public function con()
    {
        $host = "localhost:3308";
        $user = "root";
        $pass = "";
        $db   = "students";
        $connection = mysqli_connect($host,$user,$pass,$db);
        if ($connection==true){
            return $connection;
        }else{
            die();
        }
    }

    public function query($sql)
    {
        return mysqli_query($this->con(),$sql);
    }
    public function rnquery($sql)
    {
        mysqli_query($this->con(),$sql);
    }

    public function checexist($sql){
        $chck = mysqli_query($this->con(),$sql);
        $rows = mysqli_num_rows($chck);
        if($rows > 0){
            return true;
        }else{
            return false;
        }
    }
}