<?php
    require ('phpmailer/PHPMailerAutoload.php');
    
    function verifyChangePass(){
        $config = new Config();
        $subject = "Please verify your email";
        $message = '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>'.$subject.'</title>
        </head>
        <body>
            <p>Hi '.$name.'<br/>
            Thanks for register verify your email address <a href="'.$config->mhost.'?verify='.$auth.'">Verify</a>
            </p>
        </body>
        </html>
        ';
        echo "<script>window.location.href='welcome.php?registerd=$email&nm=$name'</script>";
        sendmail($email,$subject,$message);
    }

    function registerVerify($email,$name,$auth){
        $config = new Config();
        $subject = "Please verify your email";
        $message = '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>'.$subject.'</title>
        </head>
        <body>
            <p>Hi '.$name.'<br/>
            Thanks for register verify your email address <a href="'.$config->mhost.'?verify='.$auth.'">Verify</a>
            </p>
        </body>
        </html>
        ';
        echo "<script>window.location.href='welcome.php?registerd=$email&nm=$name'</script>";
        sendmail($email,$subject,$message);
    }
    function sendmail($email,$subject,$message){
        
        $mail = new PHPMailer;
        $config = new Config();
        $mail->SMTPDebug = 4;
        $mail->isSMTP();
        $mail->Host      = $config->mhost;
        $mail->SMTPAuth  = true;
        $mail->Username  = $config->musr;
        $mail->Password  = $config->mpass;
        $mail->SMTPSecure ='tls';
        $mail->Port       = 587;
        $mail->setFrom($config->musr,"Emmanueluzo");
        $mail->addAddress($email);
        $mail->addReplyTo($config->musr,"Emmanueluzo");
        $mail->isHTML(true);
        $mail->Subject  = $subject;
        $mail->Body = $message;
        $mail->AltBody = "Verification Message";
        $send         = $mail->send();

    }


?>